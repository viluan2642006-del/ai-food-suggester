import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Brain, Utensils } from 'lucide-react';

export default function App() {
  const [dish, setDish] = useState('');
  const [loading, setLoading] = useState(false);

  const dishes = [
    'Phở bò',
    'Bún chả',
    'Cơm tấm sườn',
    'Mì Quảng',
    'Gỏi cuốn',
    'Hủ tiếu Nam Vang',
    'Lẩu thái',
    'Cháo lòng',
    'Bánh mì trứng ốp la',
    'Bún riêu cua'
  ];

  const suggestDish = () => {
    setLoading(true);
    setTimeout(() => {
      const randomDish = dishes[Math.floor(Math.random() * dishes.length)];
      setDish(randomDish);
      setLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-yellow-100 via-orange-100 to-pink-100 text-gray-800 p-6">
      <div className="w-full max-w-md shadow-xl rounded-2xl bg-white/80 backdrop-blur-sm border border-orange-200 p-6 text-center">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
          <div className="flex items-center justify-center mb-4 text-orange-500">
            <Brain className="w-8 h-8 mr-2" />
            <h1 className="text-2xl font-bold">AI Gợi Ý Món Ăn</h1>
          </div>
          <p className="text-sm text-gray-600 mb-6">
            Hãy để AI giúp bạn chọn món ăn hôm nay! 🍽️
          </p>
          <button
            onClick={suggestDish}
            disabled={loading}
            className="bg-orange-400 hover:bg-orange-500 text-white px-6 py-2 rounded-full shadow-md transition"
          >
            {loading ? 'Đang suy nghĩ...' : 'Gợi ý món ăn'}
          </button>
          {dish && !loading && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="mt-6"
            >
              <div className="flex items-center justify-center text-2xl font-semibold text-orange-600">
                <Utensils className="w-6 h-6 mr-2" /> {dish}
              </div>
            </motion.div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
